import { IdeaInput, ValidationResult } from "../types";

export class ApiError extends Error {
  status: number;
  details?: unknown;

  constructor(message: string, status: number, details?: unknown) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.details = details;
  }
}

export async function validateIdea(input: IdeaInput, signal?: AbortSignal): Promise<ValidationResult> {
  const res = await fetch("/api/validate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input),
    signal,
  });

  const contentType = res.headers.get("content-type") || "";
  const data = contentType.includes("application/json") ? await res.json() : await res.text();

  if (!res.ok) {
    const message = typeof data === "object" && data && "error" in (data as any)
      ? String((data as any).error)
      : `Request failed (${res.status})`;
    throw new ApiError(message, res.status, data);
  }

  return data as ValidationResult;
}
