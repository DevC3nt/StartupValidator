
import React, { useEffect, useMemo, useState } from 'react';
import { IdeaInput } from '../types';

interface InputFormProps {
  onValidate: (input: IdeaInput) => void;
  isLoading: boolean;
}

export const InputForm: React.FC<InputFormProps> = ({ onValidate, isLoading }) => {
  const DRAFT_KEY = 'reality_check_draft_v1';

  const [form, setForm] = useState<IdeaInput>({
    title: '',
    description: '',
    targetAudience: '',
    revenueModel: ''
  });

  const [touched, setTouched] = useState(false);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(DRAFT_KEY);
      if (saved) {
        const parsed = JSON.parse(saved) as Partial<IdeaInput>;
        setForm((prev) => ({ ...prev, ...parsed }));
      }
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(DRAFT_KEY, JSON.stringify(form));
    } catch {
      // ignore
    }
  }, [form]);

  const errors = useMemo(() => {
    const e: string[] = [];
    if (!form.title.trim()) e.push('Add a clear title.');
    if (form.description.trim().length < 40) e.push('Your pitch is too short. Add real details.');
    if (form.description.length > 2000) e.push('Your pitch is too long. Keep it under 2000 characters.');
    return e;
  }, [form]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTouched(true);
    if (errors.length > 0) return;
    onValidate(form);
  };

  return (
    <form onSubmit={handleSubmit} className="glass p-8 rounded-2xl space-y-6 shadow-2xl">
      <div className="space-y-2">
        <label className="block text-sm font-semibold text-slate-300">Project Title</label>
        <input
          required
          type="text"
          placeholder="e.g., Uber for Dog Walkers"
          className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-rose-500 transition-all"
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          onBlur={() => setTouched(true)}
        />
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-semibold text-slate-300">The "Vision" (Elevator Pitch)</label>
        <textarea
          required
          rows={4}
          placeholder="What problem are you solving and how? Be specific."
          className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-rose-500 transition-all"
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          onBlur={() => setTouched(true)}
        />
        <div className="flex items-center justify-between text-xs text-slate-500">
          <span>Be specific: customers, channels, pricing, and what you build first.</span>
          <span className={form.description.length > 2000 ? 'text-rose-400' : ''}>{form.description.length}/2000</span>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="block text-sm font-semibold text-slate-300">Target Audience</label>
          <input
            type="text"
            placeholder="Who actually pays for this?"
            className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-rose-500 transition-all"
            value={form.targetAudience}
            onChange={(e) => setForm({ ...form, targetAudience: e.target.value })}
          />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-semibold text-slate-300">Revenue Model</label>
          <input
            type="text"
            placeholder="SaaS, Marketplace, etc."
            className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-rose-500 transition-all"
            value={form.revenueModel}
            onChange={(e) => setForm({ ...form, revenueModel: e.target.value })}
          />
        </div>
      </div>

      <button
        disabled={isLoading || (touched && errors.length > 0)}
        type="submit"
        className="w-full bg-rose-600 hover:bg-rose-500 disabled:bg-rose-800 disabled:cursor-not-allowed text-white font-bold py-4 rounded-lg transition-all shadow-lg flex items-center justify-center gap-2 text-lg"
      >
        {isLoading ? (
          <>
            <i className="fas fa-spinner fa-spin"></i>
            Analyzing Market Failures...
          </>
        ) : (
          <>
            <i className="fas fa-bolt"></i>
            Validate My Idea
          </>
        )}
      </button>

      {touched && errors.length > 0 && (
        <div className="p-3 rounded-lg bg-rose-900/20 border border-rose-500/20 text-rose-100 text-sm">
          <div className="flex items-center gap-2 font-semibold">
            <i className="fas fa-triangle-exclamation"></i>
            Fix this before running the analysis
          </div>
          <ul className="mt-2 list-disc pl-5 space-y-1">
            {errors.map((er) => (
              <li key={er}>{er}</li>
            ))}
          </ul>
        </div>
      )}
      <p className="text-center text-xs text-slate-500 italic">Warning: The results may be discouraging. Only proceed if you can handle the truth.</p>
    </form>
  );
};
