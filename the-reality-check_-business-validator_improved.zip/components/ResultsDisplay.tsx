
import React, { useMemo, useState } from 'react';
import { ValidationResult } from '../types';
import { RiskChart } from './RiskChart';

interface ResultsDisplayProps {
  result: ValidationResult;
  onReset: () => void;
}

export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ result, onReset }) => {
  const [copied, setCopied] = useState(false);

  const markdown = useMemo(() => {
    const lines: string[] = [];
    lines.push(`# Reality Check`);
    lines.push('');
    lines.push(`## Verdict`);
    lines.push(`**Honesty score:** ${Math.round(result.brutalHonestyScore)}%`);
    lines.push('');
    lines.push(`> ${result.overallVerdict}`);
    lines.push('');
    lines.push('## Breakdown');
    lines.push(result.breakdown);
    lines.push('');
    lines.push('## Risks');
    for (const r of result.risks) {
      lines.push(`- **${r.category}** (severity ${r.severity}/10)  `);
      lines.push(`  ${r.description}  `);
      lines.push(`  _Why mitigation fails:_ ${r.mitigationFailures}`);
    }
    lines.push('');
    lines.push('## Assumptions');
    for (const a of result.assumptions) {
      lines.push(`- **${a.assumption}** (${a.fatalFlawProbability}% fatal)  `);
      lines.push(`  ${a.realityCheck}`);
    }
    lines.push('');
    lines.push('## Competitors');
    for (const c of result.competitors) {
      lines.push(`- **${c.name}**  `);
      lines.push(`  Strength: ${c.strength}  `);
      lines.push(`  Edge: ${c.advantage}  `);
      lines.push(`  Why you might lose: ${c.whyYouMightLose}`);
    }
    lines.push('');
    lines.push('## Revenue stress test');
    lines.push(`- Scenarios: ${result.revenueStressTest.scenarios}`);
    lines.push(`- Unit economics warning: ${result.revenueStressTest.unitEconomicsWarning}`);
    lines.push('');
    lines.push('## Survival roadmap');
    result.roadmap.forEach((p, idx) => {
      lines.push(`${idx + 1}. **${p.phase}**`);
      lines.push(`   - Survival metric: ${p.survivalMetric}`);
      for (const act of p.actions) lines.push(`   - ${act}`);
    });
    lines.push('');
    return lines.join('\n');
  }, [result]);

  const copyMarkdown = async () => {
    try {
      await navigator.clipboard.writeText(markdown);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1200);
    } catch {
      setCopied(false);
      alert('Copy failed. Your browser may block clipboard access.');
    }
  };

  const downloadMarkdown = () => {
    const blob = new Blob([markdown], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'reality-check.md';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-12 pb-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Top Verdict Section */}
      <section className="glass p-8 rounded-3xl border-rose-500/30">
        <div className="flex items-center justify-end gap-2 mb-4">
          <button
            type="button"
            onClick={copyMarkdown}
            className="text-xs px-3 py-2 rounded-lg bg-slate-900/40 border border-slate-700/40 hover:border-slate-500/60 transition flex items-center gap-2"
            title="Copy results as Markdown"
          >
            <i className="fas fa-copy"></i>
            {copied ? 'Copied' : 'Copy'}
          </button>
          <button
            type="button"
            onClick={downloadMarkdown}
            className="text-xs px-3 py-2 rounded-lg bg-slate-900/40 border border-slate-700/40 hover:border-slate-500/60 transition flex items-center gap-2"
            title="Download results as a Markdown file"
          >
            <i className="fas fa-file-arrow-down"></i>
            Download
          </button>
        </div>
        <div className="flex flex-col md:flex-row gap-8 items-center">
          <div className="flex-1">
            <h2 className="text-3xl font-bold text-rose-500 mb-4 flex items-center gap-3">
              <i className="fas fa-gavel"></i>
              The Verdict
            </h2>
            <p className="text-xl text-slate-200 leading-relaxed italic">
              "{result.overallVerdict}"
            </p>
          </div>
          <div className="flex flex-col items-center justify-center p-6 bg-slate-900 rounded-2xl border border-slate-800">
            <span className="text-xs text-slate-500 uppercase tracking-widest font-bold mb-1">Honesty Score</span>
            <span className={`text-6xl font-black ${result.brutalHonestyScore > 70 ? 'text-rose-500' : 'text-amber-500'}`}>
              {result.brutalHonestyScore}%
            </span>
            <span className="text-xs text-slate-400 mt-2">Likelihood of failure</span>
          </div>
        </div>
      </section>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Risk Breakdown */}
        <section className="glass p-6 rounded-2xl">
          <h3 className="text-xl font-bold mb-6 border-b border-slate-700 pb-2 flex items-center gap-2">
            <i className="fas fa-biohazard text-rose-500"></i>
            Risk Profile
          </h3>
          <RiskChart risks={result.risks} />
          <div className="space-y-4 mt-6">
            {result.risks.map((risk, i) => (
              <div key={i} className="bg-slate-900/50 p-4 rounded-lg border border-slate-800">
                <div className="flex justify-between items-center mb-1">
                  <span className="font-bold text-rose-400">{risk.category}</span>
                  <span className="text-xs bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded">Severity: {risk.severity}/10</span>
                </div>
                <p className="text-sm text-slate-400 mb-2">{risk.description}</p>
                <div className="text-xs text-slate-500 border-t border-slate-800 pt-2">
                  <span className="text-rose-600 font-bold uppercase mr-1">Why mitigation fails:</span>
                  {risk.mitigationFailures}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Assumptions & Reality Check */}
        <section className="glass p-6 rounded-2xl">
          <h3 className="text-xl font-bold mb-6 border-b border-slate-700 pb-2 flex items-center gap-2">
            <i className="fas fa-eye text-sky-500"></i>
            Flawed Assumptions
          </h3>
          <div className="space-y-6">
            {result.assumptions.map((item, i) => (
              <div key={i} className="relative pl-4 border-l-2 border-slate-700">
                <div className="text-sm font-semibold text-slate-500 mb-1 flex justify-between">
                  <span>Assumption: "{item.assumption}"</span>
                  <span className="text-rose-500">{item.fatalFlawProbability}% Fatal</span>
                </div>
                <p className="text-slate-200">
                  <i className="fas fa-arrow-right text-sky-500 mr-2 text-xs"></i>
                  {item.realityCheck}
                </p>
              </div>
            ))}
          </div>

          <h3 className="text-xl font-bold mt-12 mb-6 border-b border-slate-700 pb-2 flex items-center gap-2">
            <i className="fas fa-money-bill-wave text-emerald-500"></i>
            Revenue Stress Test
          </h3>
          <div className="space-y-4">
            <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg">
              <h4 className="text-xs font-bold text-slate-500 uppercase mb-2">Worst Case Scenarios</h4>
              <p className="text-sm text-slate-300 leading-relaxed">{result.revenueStressTest.scenarios}</p>
            </div>
            <div className="p-4 bg-rose-900/20 border border-rose-500/20 rounded-lg">
              <h4 className="text-xs font-bold text-rose-400 uppercase mb-2">Unit Economics Warning</h4>
              <p className="text-sm text-rose-100">{result.revenueStressTest.unitEconomicsWarning}</p>
            </div>
          </div>
        </section>
      </div>

      {/* Competitor Analysis */}
      <section className="glass p-8 rounded-2xl">
        <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
          <i className="fas fa-shield-halved text-amber-500"></i>
          Competitor Simulation
        </h3>
        <div className="grid md:grid-cols-3 gap-4">
          {result.competitors.map((comp, i) => (
            <div key={i} className="p-4 bg-slate-900/80 rounded-xl border border-slate-800 flex flex-col group transition-all hover:border-rose-500/40">
              <h4 className="text-lg font-bold text-slate-100 mb-3 flex items-center justify-between">
                {comp.name}
                <i className="fas fa-ghost text-slate-700 group-hover:text-rose-900 transition-colors"></i>
              </h4>
              
              <div className="mb-3">
                <span className="text-[10px] text-amber-500 uppercase font-bold block mb-1">Their Strength</span>
                <p className="text-xs text-slate-300 leading-tight">{comp.strength}</p>
              </div>

              <div className="mb-4">
                <span className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Their Edge</span>
                <p className="text-xs text-slate-400 leading-tight">{comp.advantage}</p>
              </div>

              <div className="mt-auto pt-3 border-t border-slate-800 bg-rose-950/5 rounded-b-lg -mx-4 px-4 pb-2">
                <span className="text-[10px] text-rose-500 uppercase font-bold flex items-center gap-1 mb-1">
                  <i className="fas fa-skull-crossbones text-[8px]"></i>
                  Potential Downfall
                </span>
                <p className="text-xs text-rose-200 italic leading-snug font-medium">
                  {comp.whyYouMightLose}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* MVP Roadmap */}
      <section className="glass p-8 rounded-2xl">
        <h3 className="text-xl font-bold mb-8 flex items-center gap-2">
          <i className="fas fa-map-location-dot text-indigo-500"></i>
          Survival Roadmap
        </h3>
        <div className="space-y-8">
          {result.roadmap.map((step, i) => (
            <div key={i} className="flex gap-6 relative">
              {i < result.roadmap.length - 1 && (
                <div className="absolute left-4 top-10 bottom-0 w-0.5 bg-slate-800"></div>
              )}
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-bold z-10">
                {i + 1}
              </div>
              <div className="flex-1 bg-slate-900/40 p-5 rounded-xl border border-slate-800">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                  <h4 className="text-lg font-bold text-slate-100">{step.phase}</h4>
                  <div className="px-3 py-1 bg-indigo-500/10 border border-indigo-500/30 rounded-full">
                    <span className="text-[10px] font-bold text-indigo-400 uppercase mr-2">Kill Criterion:</span>
                    <span className="text-sm font-medium text-slate-200">{step.survivalMetric}</span>
                  </div>
                </div>
                <ul className="grid md:grid-cols-2 gap-2">
                  {step.actions.map((action, j) => (
                    <li key={j} className="text-sm text-slate-400 flex items-start gap-2">
                      <span className="text-indigo-500 mt-1">•</span>
                      {action}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </section>

      <div className="flex justify-center">
        <button
          onClick={onReset}
          className="bg-slate-800 hover:bg-slate-700 text-white px-8 py-3 rounded-full transition-all border border-slate-600 flex items-center gap-2"
        >
          <i className="fas fa-undo"></i>
          Test Another Idea
        </button>
      </div>
    </div>
  );
};
