
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col items-center p-4 md:p-8">
      <header className="w-full max-w-5xl mb-12 text-center">
        <h1 className="text-4xl md:text-6xl font-extrabold mb-4 tracking-tighter">
          REALITY <span className="gradient-text">CHECK</span>
        </h1>
        <p className="text-slate-400 text-lg max-w-2xl mx-auto">
          Brutally testing startup ideas before money is wasted. Input your "vision," we'll give you the reality.
        </p>
      </header>
      <main className="w-full max-w-5xl flex-grow">
        {children}
      </main>
      <footer className="mt-20 py-8 border-t border-slate-800 w-full max-w-5xl text-center text-slate-500 text-sm">
        <p>© {new Date().getFullYear()} Reality Check Business Validator. No sugar-coating included.</p>
      </footer>
    </div>
  );
};
