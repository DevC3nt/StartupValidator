import { z } from "zod";

export const ideaInputSchema = z.object({
  title: z.string().trim().min(3).max(120),
  description: z.string().trim().min(40).max(2000),
  targetAudience: z.string().trim().max(200).optional().default(""),
  revenueModel: z.string().trim().max(200).optional().default(""),
});

export type IdeaInput = z.infer<typeof ideaInputSchema>;

export const validationResultSchema = z.object({
  overallVerdict: z.string(),
  brutalHonestyScore: z.number(),
  breakdown: z.string(),
  risks: z.array(z.object({
    category: z.string(),
    severity: z.number(),
    description: z.string(),
    mitigationFailures: z.string(),
  })),
  assumptions: z.array(z.object({
    assumption: z.string(),
    realityCheck: z.string(),
    fatalFlawProbability: z.number(),
  })),
  competitors: z.array(z.object({
    name: z.string(),
    strength: z.string(),
    advantage: z.string(),
    whyYouMightLose: z.string(),
  })),
  revenueStressTest: z.object({
    scenarios: z.string(),
    unitEconomicsWarning: z.string(),
  }),
  roadmap: z.array(z.object({
    phase: z.string(),
    actions: z.array(z.string()),
    survivalMetric: z.string(),
  })),
});

export type ValidationResult = z.infer<typeof validationResultSchema>;
