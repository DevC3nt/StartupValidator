import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import dotenv from "dotenv";
import { z } from "zod";
import LRUCache from "lru-cache";

import { validateIdeaWithGemini } from "./validate";
import { ideaInputSchema } from "./zodSchemas";

dotenv.config();

const app = express();

app.use(helmet());
app.use(cors({ origin: true }));
app.use(express.json({ limit: "40kb" }));

const limiter = rateLimit({
  windowMs: 60_000,
  max: 12,
  standardHeaders: true,
  legacyHeaders: false,
});

const cache = new LRUCache<string, unknown>({
  max: 200,
  ttl: 1000 * 60 * 15,
});

app.get("/api/health", (_req, res) => {
  res.json({ ok: true });
});

app.post("/api/validate", limiter, async (req, res) => {
  try {
    const input = ideaInputSchema.parse(req.body);
    const cacheKey = JSON.stringify(input);
    const cached = cache.get(cacheKey);
    if (cached) return res.json(cached);

    const result = await validateIdeaWithGemini(input);
    cache.set(cacheKey, result);
    return res.json(result);
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: "Invalid input.", issues: err.issues });
    }
    const message = err instanceof Error ? err.message : "Unknown error";
    // Hide internal details by default
    return res.status(500).json({ error: "Failed to run analysis.", details: message });
  }
});

const port = Number(process.env.PORT || 8787);
app.listen(port, () => {
  // eslint-disable-next-line no-console
  console.log(`API listening on http://localhost:${port}`);
});
